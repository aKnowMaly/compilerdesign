# Expanded external corpus

```json
{
  "schema_version": 1,
  "source_commit": "4b2c892865cbbb05ee996c88794a58e17d3adb81",
  "families_selected": [
    "SingleSource/Benchmarks/Stanford",
    "SingleSource/Benchmarks/Shootout",
    "SingleSource/Benchmarks/Misc",
    "SingleSource/Benchmarks/CoyoteBench",
    "MultiSource/Benchmarks/BitBench",
    "MultiSource/Benchmarks/McCat",
    "MultiSource/Benchmarks/Olden",
    "MultiSource/Benchmarks/Ptrdist",
    "MultiSource/Benchmarks/FreeBench",
    "MultiSource/Benchmarks/Prolangs-C"
  ],
  "toolchain": "Ubuntu clang version 18.1.3 (1ubuntu1)\nTarget: x86_64-pc-linux-gnu\nThread model: posix\nInstalledDir: /usr/lib/llvm-18/bin",
  "pass_source_sha256": "0695145aef63b272b147124ebea137dde9da2c6a92c80c6721cc63f4cef73949",
  "targets_discovered": 108,
  "programs_evaluated": 107,
  "unique_evaluated_source_sets": 107,
  "compilation_units": 456,
  "unique_source_content_hashes": 451,
  "status_counts": {
    "EVALUATED": 107,
    "EXCLUDED_NON_C": 1
  },
  "width_choice_eligible_programs": 14,
  "width_instruction_better": 4,
  "width_instruction_equal": 10,
  "width_instruction_worse": 0,
  "BC_allocation_mismatches": 0,
  "limitations": "Programs are clustered by family; source-set hashes detect exact source duplicates, not algorithmic similarity. No runtime speed or energy measurement. Raw output equivalence is tested only against repeatable successful baselines.",
  "source_sets_shared_with_mibench": 0,
  "unique_external_source_sets_including_mibench": 124,
  "protocol_sha256": "da68a83b50320f803972207e2410a745b2968428a10af12d177e41dddad7fe73",
  "A": {
    "candidates": 4205,
    "transformed": 26,
    "positive": 24,
    "neutral": 2,
    "saved_bytes": 579,
    "pass": 103,
    "fail": 0,
    "skip": 4,
    "programs_transformed": 16,
    "observable_passes": 101
  },
  "B": {
    "candidates": 4205,
    "transformed": 24,
    "positive": 24,
    "neutral": 0,
    "saved_bytes": 579,
    "pass": 103,
    "fail": 0,
    "skip": 4,
    "programs_transformed": 15,
    "observable_passes": 101
  },
  "C": {
    "candidates": 4205,
    "transformed": 24,
    "positive": 24,
    "neutral": 0,
    "saved_bytes": 579,
    "pass": 103,
    "fail": 0,
    "skip": 4,
    "programs_transformed": 15,
    "observable_passes": 101
  },
  "width_instruction_delta_C_minus_B": -22,
  "width_text_delta_C_minus_B": -128,
  "runtime_validated_width_choice_programs": 11
}
```
